package com.example.walmart

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import com.example.walmart.data.MainRepository
import com.example.walmart.data.Product
import com.example.walmart.databinding.ActivityMainBinding
import com.example.walmart.network.RetrofitService
import com.example.walmart.viewmodel.MainViewModel
import com.example.walmart.viewmodel.MyViewModelFactory
import com.example.walmart.viewmodel.ViewState

class MainActivity : AppCompatActivity() {

    private val TAG = "MainActivity"
    private lateinit var binding: ActivityMainBinding

    val viewModel: MainViewModel by lazy{
        ViewModelProvider(this,
            MyViewModelFactory(MainRepository(retrofitService))).get(
            MainViewModel::class.java)
    }

    private val retrofitService = RetrofitService.getInstance()
    val adapter = MainAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.recyclerview.adapter = adapter

        viewModel.productList.observe(this, Observer {
            when (it){
                is ViewState.Response -> {updateAdapter(it.data)}
                is ViewState.Error -> {showError(it.errorMessage)}
            }
        })

        viewModel.getProducts()
    }

    fun updateAdapter(dataSet: List<Product>){
            adapter.setProductList(dataSet)

    }

    fun showError(errorMessage: String){
        Toast.makeText(this, errorMessage, Toast.LENGTH_SHORT).show()
    }
}