package com.example.walmart

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.example.walmart.data.Product
import com.example.walmart.databinding.RowItemBinding

class MainAdapter: RecyclerView.Adapter<MainAdapter.MainViewHolder>() {

    var products = mutableListOf<Product>()

    fun setProductList(movies: List<Product>) {
        this.products = movies.toMutableList()
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MainViewHolder {
        val inflater = LayoutInflater.from(parent.context)

        val binding = RowItemBinding.inflate(inflater, parent, false)
        return MainViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MainViewHolder, position: Int) {
        val product = products[position]
        holder.binding.productName.text = product.productName
        Glide.with(holder.itemView.context)
            .load(product.productImage)
            .into(holder.binding.productImage)

    }

    override fun getItemCount(): Int {
        return products.size
    }

    class MainViewHolder(val binding: RowItemBinding) : RecyclerView.ViewHolder(binding.root) {

    }
}

