package com.example.walmart.data

data class Response(

    val products: Array<Product>

)

data class Product(

    val productId: String,
    val productName: String,
    val shortDescription: String,
    val longDescription: String,
    val price: String,
    val productImage: String,
    val reviewRating: Int,
    val reviewCount:Int,
    val inStock: Boolean
)