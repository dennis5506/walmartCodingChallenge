package com.example.walmart.network

import com.example.walmart.data.Product
import retrofit2.Call
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.GET

interface RetrofitService {


    @GET("1/10")
    fun getProducts(): Call<List<Product>>



    companion object{

        var retrofitService: RetrofitService? = null

        fun getInstance(): RetrofitService{

            if(retrofitService == null){
                val retrofit = Retrofit.Builder()
                    .baseUrl("https://mobile-tha-server.firebaseapp.com//walmartproducts/")
                    .addConverterFactory(GsonConverterFactory.create())
                    .build()

                retrofitService = retrofit.create(RetrofitService::class.java)
            }

            return retrofitService!!
        }
    }
}