package com.example.walmart.data

import com.example.walmart.network.RetrofitService

class MainRepository constructor(private val retrofitService: RetrofitService) {

    fun getProducts() = retrofitService.getProducts()
}