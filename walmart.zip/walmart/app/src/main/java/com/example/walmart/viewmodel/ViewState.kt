package com.example.walmart.viewmodel

import com.example.walmart.data.Product

sealed class ViewState{
    data class Response(val data: List<Product>): ViewState()
    data class Error(val errorMessage: String): ViewState()
}
