package com.example.walmart.viewmodel

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.example.walmart.data.MainRepository
import com.example.walmart.data.Product
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainViewModel constructor(private val repository: MainRepository) : ViewModel() {
    private val _productList = MutableLiveData<ViewState>()
    val productList: LiveData<ViewState>
    get() = _productList

    fun getProducts() {

        val response = repository.getProducts()
        response.enqueue(object : Callback<List<Product>> {
            override fun onResponse(call: Call<List<Product>>, response: Response<List<Product>>) {
                if (response.isSuccessful) {
                    _productList.postValue(
                        response.body()?.let {
                            ViewState.Response(it)
                        }
                    )
                }else{
                    _productList.postValue(
                        ViewState.Error(response.message())
                    )
                }
            }

            override fun onFailure(call: Call<List<Product>>, t: Throwable) {
                _productList.postValue(ViewState.Error(t.message ?: "Unknown Error"))
            }
        })
    }
}
